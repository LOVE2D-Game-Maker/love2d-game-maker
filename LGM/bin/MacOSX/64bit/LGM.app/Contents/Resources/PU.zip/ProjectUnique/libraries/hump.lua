--A custom file made for Project Unique to make the loading of the HUMP libraries simpler. ;)
require "ProjectUnique.libraries.hump.camera"
Class = require "ProjectUnique.libraries.hump.class"
require "ProjectUnique.libraries.hump.gamestate"
require "ProjectUnique.libraries.hump.signal"
require "ProjectUnique.libraries.hump.timer"
require "ProjectUnique.libraries.hump.vector-light"
require "ProjectUnique.libraries.hump.vector"